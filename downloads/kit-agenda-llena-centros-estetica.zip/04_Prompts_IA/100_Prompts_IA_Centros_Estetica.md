# 100 prompts de IA para centros de estética

Sustituye los campos entre llaves antes de usar.

## Prompt 001 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito analizar mis servicios actuales y detectar cuáles deberían ser mis tratamientos estrella. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 002 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una propuesta de valor clara para mi centro de estética en {ciudad}. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 003 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito definir el perfil de clienta ideal para tratamientos faciales, corporales y bienestar. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 004 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito identificar los principales huecos de mi agenda y proponer acciones para llenarlos. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 005 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un mapa de campañas para los próximos 30 días. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 006 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diferenciar mi centro de competidores que compiten solo por precio. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 007 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una política simple de reservas, cambios y cancelaciones. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 008 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar una experiencia post-tratamiento para aumentar recompra. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 009 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito preparar una oferta de entrada rentable para nuevas clientas. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 010 - Estrategia y diagnóstico
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito convertir servicios sueltos en planes de seguimiento. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 011 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear 10 ideas de Reels para vender tratamientos faciales sin sonar agresiva. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 012 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito escribir un carrusel educativo sobre errores comunes en el cuidado de la piel. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 013 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito generar hooks de 3 segundos para videos de estética. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 014 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear captions para antes/después sin prometer resultados garantizados. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 015 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito preparar una semana de Stories para vender una promoción. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 016 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito escribir un post de prueba social usando testimonios reales. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 017 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear ideas de contenido para mostrar higiene, cabina y profesionalidad. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 018 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito hacer un calendario de contenidos para publicar de lunes a domingo. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 019 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito convertir una duda frecuente en Reel corto. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 020 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una llamada a la acción para reservar por WhatsApp. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 021 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito redactar 5 versiones de un anuncio para Meta Ads a WhatsApp. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 022 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear contenido para clientas que tienen miedo de probar un tratamiento. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 023 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito escribir posts para promover bonos de 3 y 5 sesiones. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 024 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear ideas de contenido para fechas comerciales locales. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 025 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito hacer un guion para un video de 15 segundos sobre agenda llena. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 026 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear 10 titulares para una limpieza facial premium. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 027 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito escribir Stories interactivas con encuestas y preguntas. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 028 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito convertir una reseña positiva en contenido de redes. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 029 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear contenido para reactivar clientas dormidas. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 030 - Instagram, TikTok y Facebook
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito hacer un post comparando sesión suelta vs plan de cuidado. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 031 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una respuesta inicial para una clienta que pregunta precio. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 032 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar un flujo de WhatsApp para pasar de consulta a reserva. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 033 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito responder a una objeción de precio sin bajar el valor. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 034 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un mensaje de confirmación de cita. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 035 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear recordatorios 48 h y 24 h antes de la cita. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 036 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito redactar un mensaje amable para reprogramar una cita. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 037 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un mensaje post-tratamiento con cuidados posteriores. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 038 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito pedir una reseña sin sonar insistente. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 039 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito recuperar una clienta que no volvió en 60 días. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 040 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un mensaje para vender un bono después de la primera sesión. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 041 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar respuestas rápidas para preguntas frecuentes. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 042 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un mensaje para no-shows. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 043 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un texto para explicar política de seña. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 044 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una campaña de referidos por WhatsApp. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 045 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un mensaje VIP para clientas frecuentes. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 046 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito hacer seguimiento a una lead que pidió información y no respondió. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 047 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un mensaje de lista de espera. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 048 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una invitación a diagnóstico inicial. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 049 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito redactar una respuesta para clienta indecisa. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 050 - WhatsApp y atención al cliente
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un mensaje de cierre con horarios disponibles. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 051 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar una promoción de primera visita rentable. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 052 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un bono facial de 3 sesiones con buen margen. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 053 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un paquete corporal sin prometer resultados garantizados. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 054 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito hacer una campaña de cumpleaños del mes. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 055 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar una oferta de amigas o referidos. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 056 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una tarjeta regalo digital. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 057 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una promoción para llenar horarios valle. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 058 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un plan VIP trimestral para clientas recurrentes. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 059 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito hacer una campaña para San Valentín o Día de la Madre. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 060 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un bono de continuidad post-tratamiento. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 061 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar un order bump para vender junto al tratamiento inicial. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 062 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una oferta de temporada según clima y país. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 063 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito hacer una campaña de regreso a rutina. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 064 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una promo flash de 48 horas con urgencia real. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 065 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un paquete de evento/boda/graduación. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 066 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar una campaña de recuperación de clientas dormidas. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 067 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una promoción para Google Reviews sin comprar reseñas. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 068 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito hacer una campaña de fin de mes para cerrar agenda. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 069 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una escalera de ofertas básica, premium y VIP. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 070 - Promociones y bonos
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear textos para vender paquetes sin parecer desesperada. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 071 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito responder una reseña positiva de forma personalizada. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 072 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito responder una reseña negativa con profesionalidad. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 073 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un protocolo para pedir reseñas después de cada visita. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 074 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito optimizar la descripción de Google Business Profile. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 075 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear respuestas para preguntas frecuentes en Google. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 076 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito convertir reseñas en publicaciones para redes sociales. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 077 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar un mensaje para recuperar una mala experiencia. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 078 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un checklist semanal de reputación online. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 079 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito redactar un texto para solicitar reseña por WhatsApp. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 080 - Reseñas, reputación y Google
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una estrategia para subir reseñas locales en 30 días. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 081 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una tabla CRM simple para clientas de estética. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 082 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito segmentar clientas nuevas, recurrentes, dormidas y VIP. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 083 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito definir métricas semanales de agenda llena. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 084 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear un reporte semanal de leads, reservas y ventas. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 085 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar una rutina diaria de 15 minutos para seguimiento. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 086 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear campos para registrar tratamiento, fecha y próxima acción. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 087 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito hacer un sistema para detectar clientas que deberían volver. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 088 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una campaña según último tratamiento realizado. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 089 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito crear una plantilla de seguimiento de no-shows. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.

## Prompt 090 - Reservas, CRM y métricas
Actúa como consultor experto en marketing para centros de estética en Latinoamérica. Necesito diseñar un tablero de KPIs para el centro. Mi centro está en {ciudad}, atiende a {tipo_de_clienta}, ofrece {tratamientos}, tiene precios promedio de {ticket_medio} y quiero lograr {objetivo}. Entrégame una propuesta práctica con: idea principal, texto listo para usar, pasos de ejecución, CTA por WhatsApp y una advertencia para no prometer resultados irreales.
